import 'dart:io';
import 'dart:math';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'db.dart';
import 'io.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await DB.init();
  runApp(MaterialApp(
    title: 'CBHI Registration',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorSchemeSeed: Colors.teal, useMaterial3: true),
    home: const Home(),
  ));
}

Widget tf(String l, TextEditingController c) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: TextField(controller: c, decoration: InputDecoration(labelText: l, border: const OutlineInputBorder())));

Widget dd(String l, String? v, List<String> items, void Function(String?) on, {Map<String, String>? text}) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: DropdownButtonFormField<String>(
        value: items.contains(v) ? v : null,
        decoration: InputDecoration(labelText: l, border: const OutlineInputBorder()),
        items: [for (final i in items) DropdownMenuItem(value: i, child: Text(text?[i] ?? i))],
        onChanged: on));

void snack(BuildContext c, String m) => ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int i = 0;
  @override
  Widget build(BuildContext c) => Scaffold(
        body: [const HouseholdsPage(), const KebelesPage(), const SettingsPage(), const DashboardPage()][i],
        bottomNavigationBar: NavigationBar(selectedIndex: i, onDestinationSelected: (v) => setState(() => i = v), destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: 'Households'),
          NavigationDestination(icon: Icon(Icons.account_tree), label: 'Kebeles'),
          NavigationDestination(icon: Icon(Icons.settings), label: 'Settings'),
          NavigationDestination(icon: Icon(Icons.dashboard), label: 'Dashboard'),
        ]),
      );
}

// ---------------- 1. Households ----------------
class HouseholdsPage extends StatefulWidget {
  const HouseholdsPage({super.key});
  @override
  State<HouseholdsPage> createState() => _HP();
}

class _HP extends State<HouseholdsPage> {
  List<Rec> rows = [];
  String query = '';
  int total = 0;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    rows = await DB.q('''SELECT h.*, k.name kebele,
        (SELECT name FROM member WHERE hh_id=h.id AND sub_code='00' LIMIT 1) head,
        (SELECT COUNT(*) FROM member WHERE hh_id=h.id) n
        FROM household h LEFT JOIN kebele k ON k.id=h.kebele_id
        WHERE h.search LIKE ? ORDER BY h.id DESC LIMIT 300''', ['%${query.toLowerCase()}%']);
    total = await DB.count('SELECT COUNT(*) FROM household');
    if (mounted) setState(() {});
  }

  Future<void> open(int? id) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => HouseholdForm(id: id)));
    load();
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: Text('Households ($total)')),
        floatingActionButton: FloatingActionButton.extended(onPressed: () => open(null), icon: const Icon(Icons.add), label: const Text('Add household')),
        body: Column(children: [
          Padding(
              padding: const EdgeInsets.all(10),
              child: TextField(
                  decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search name, CBHI code, FAN...', border: OutlineInputBorder()),
                  onChanged: (v) {
                    query = v.trim();
                    load();
                  })),
          Expanded(
              child: ListView.builder(
                  itemCount: rows.length,
                  itemBuilder: (_, i) {
                    final r = rows[i];
                    return ListTile(
                      leading: const CircleAvatar(child: Icon(Icons.family_restroom)),
                      title: Text('${r['head'] ?? '(no head)'}'),
                      subtitle: Text('${r['code']} • ${r['kebele'] ?? ''} • ${r['scale']} • ${r['status']} • ${r['n']} members'),
                      onTap: () => open(r['id'] as int),
                    );
                  })),
        ]),
      );
}

class HouseholdForm extends StatefulWidget {
  final int? id;
  const HouseholdForm({super.key, this.id});
  @override
  State<HouseholdForm> createState() => _HF();
}

class _HF extends State<HouseholdForm> {
  Rec h = {'scale': 'Middle', 'status': 'Un-renewed', 'area': 'Town', 'has_card': 'Yes'};
  List<Rec> ms = [], kebeles = [];
  int? kid;
  final gote = TextEditingController(), fan = TextEditingController(), enroll = TextEditingController();
  bool ready = false;
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    kebeles = await DB.q('SELECT * FROM kebele ORDER BY name');
    if (widget.id != null) {
      h = Map<String, Object?>.of((await DB.q('SELECT * FROM household WHERE id=?', [widget.id])).first);
      ms = (await DB.q('SELECT * FROM member WHERE hh_id=?', [widget.id])).map((e) => Map<String, Object?>.of(e)).toList();
      kid = h['kebele_id'] as int?;
      gote.text = '${h['gote'] ?? ''}';
      fan.text = '${h['fan'] ?? ''}';
      enroll.text = '${h['enroll'] ?? ''}';
    }
    setState(() => ready = true);
  }

  Future<void> _save() async {
    if (kid == null) return snack(context, 'Select a kebele');
    if (!ms.any((m) => m['sub_code'] == '00')) return snack(context, 'Add the Household Head as a member');
    await DB.saveHousehold(widget.id, {
      'kebele_id': kid, 'gote': gote.text.trim(), 'scale': h['scale'], 'status': h['status'], 'area': h['area'],
      'has_card': h['has_card'], 'fan': fan.text.trim(), 'enroll': enroll.text.trim(),
    }, ms);
    if (mounted) Navigator.pop(context);
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(title: const Text('Delete household and all members?'), actions: [
              TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
              FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Delete')),
            ]));
    if (ok == true) {
      await DB.deleteHousehold(widget.id!);
      if (mounted) Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext c) {
    if (!ready) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final sorted = [...ms]..sort((a, b) => '${a['sub_code']}'.compareTo('${b['sub_code']}'));
    return Scaffold(
      appBar: AppBar(title: Text(widget.id == null ? 'New household' : '${h['code']}'), actions: [
        if (widget.id != null) IconButton(onPressed: _delete, icon: const Icon(Icons.delete)),
        IconButton(onPressed: _save, icon: const Icon(Icons.save)),
      ]),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        if (widget.id == null) const Padding(padding: EdgeInsets.only(bottom: 10), child: Text('CBHI code is generated automatically when you save.')),
        Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: DropdownButtonFormField<int>(
                value: kebeles.any((k) => k['id'] == kid) ? kid : null,
                decoration: const InputDecoration(labelText: 'Kebele *', border: OutlineInputBorder()),
                items: [for (final k in kebeles) DropdownMenuItem(value: k['id'] as int, child: Text('${k['name']}'))],
                onChanged: widget.id == null ? (v) => setState(() => kid = v) : null)),
        tf('Gote', gote),
        dd('Sliding scale category *', h['scale'] as String?, fees.keys.toList(), (v) => setState(() => h['scale'] = v),
            text: {for (final e in fees.entries) e.key: '${e.key} Class (${e.value} birr)'}),
        dd('Membership status', h['status'] as String?, statuses, (v) => setState(() => h['status'] = v)),
        dd('Rural / Town', h['area'] as String?, areas, (v) => setState(() => h['area'] = v)),
        dd('Has CBHI ID card?', h['has_card'] as String?, yesNo, (v) => setState(() => h['has_card'] = v)),
        tf('Household Head National ID (FAN/FIN)', fan),
        tf('Enrollment date (DD/MM/YYYY)', enroll),
        Row(children: [
          Text('Members (${ms.length})', style: Theme.of(c).textTheme.titleMedium),
          const Spacer(),
          FilledButton.icon(
              onPressed: () async {
                final r = await memberDialog(context, null, ms);
                if (r != null) setState(() => ms.add(r));
              },
              icon: const Icon(Icons.person_add),
              label: const Text('Add member')),
        ]),
        for (final m in sorted)
          ListTile(
            leading: CircleAvatar(
                backgroundImage: (m['photo'] != null && File('${m['photo']}').existsSync()) ? FileImage(File('${m['photo']}')) : null,
                child: m['photo'] == null ? const Icon(Icons.person) : null),
            title: Text('${m['name']}'),
            subtitle: Text('${m['sub_code']} • ${m['relation']} • ${m['dob']}'),
            trailing: Row(mainAxisSize: MainAxisSize.min, children: [
              IconButton(
                  icon: const Icon(Icons.edit),
                  onPressed: () async {
                    final r = await memberDialog(context, m, ms);
                    if (r != null) setState(() => ms[ms.indexOf(m)] = r);
                  }),
              IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => setState(() => ms.remove(m))),
            ]),
          ),
        const SizedBox(height: 80),
      ]),
    );
  }
}

Future<Rec?> memberDialog(BuildContext c, Rec? m, List<Rec> all) {
  final name = TextEditingController(text: '${m?['name'] ?? ''}'), dob = TextEditingController(text: '${m?['dob'] ?? ''}');
  String gender = '${m?['gender'] ?? ''}', rel = '${m?['relation'] ?? ''}', prof = '${m?['profession'] ?? ''}';
  String? photo = m?['photo'] as String?;
  return showDialog<Rec>(
      context: c,
      builder: (_) => StatefulBuilder(
          builder: (ctx, set) => AlertDialog(
                title: Text(m == null ? 'Add member' : 'Edit member'),
                content: SingleChildScrollView(
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Row(children: [
                    CircleAvatar(
                        radius: 32,
                        backgroundImage: (photo != null && File(photo!).existsSync()) ? FileImage(File(photo!)) : null,
                        child: photo == null ? const Icon(Icons.person) : null),
                    const SizedBox(width: 12),
                    TextButton.icon(
                        icon: const Icon(Icons.photo),
                        label: const Text('Photo'),
                        onPressed: () async {
                          final r = await FilePicker.platform.pickFiles(type: FileType.image);
                          final path = r?.files.single.path;
                          if (path != null) {
                            final d = await DB.copyPhoto(path);
                            set(() => photo = d);
                          }
                        }),
                  ]),
                  const SizedBox(height: 10),
                  tf('Full name *', name),
                  tf('Date of birth (DD/MM/YYYY)', dob),
                  dd('Gender', gender, genders, (v) => set(() => gender = v ?? '')),
                  dd('Relationship', rel, relations, (v) => set(() => rel = v ?? '')),
                  dd('Profession', prof, professions, (v) => set(() => prof = v ?? '')),
                ])),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
                  FilledButton(
                      onPressed: () {
                        if (name.text.trim().isEmpty) return snack(ctx, 'Name is required');
                        if (rel == 'Household Head' && all.any((x) => x['sub_code'] == '00' && x != m)) {
                          return snack(ctx, 'This household already has a head');
                        }
                        var mx = 0;
                        for (final x in all) {
                          if (x != m) mx = max(mx, int.tryParse('${x['sub_code']}') ?? 0);
                        }
                        final sub = rel == 'Household Head'
                            ? '00'
                            : (m != null && m['sub_code'] != '00' ? '${m['sub_code']}' : (mx + 1).toString().padLeft(2, '0'));
                        Navigator.pop(ctx, <String, Object?>{
                          'sub_code': sub, 'name': name.text.trim(), 'dob': dob.text.trim(),
                          'gender': gender, 'relation': rel, 'profession': prof, 'photo': photo,
                        });
                      },
                      child: const Text('OK')),
                ],
              )));
}

// ---------------- 2. Kebele categories ----------------
class KebelesPage extends StatefulWidget {
  const KebelesPage({super.key});
  @override
  State<KebelesPage> createState() => _KP();
}

class _KP extends State<KebelesPage> {
  List<Rec> cl = [], ph = [], kb = [];
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    cl = await DB.q('SELECT * FROM cluster ORDER BY name');
    ph = await DB.q('SELECT * FROM phcu ORDER BY name');
    kb = await DB.q('SELECT * FROM kebele ORDER BY name');
    if (mounted) setState(() {});
  }

  Future<String?> ask(String t, {String? init}) => showDialog<String>(
      context: context,
      builder: (c) {
        final ctl = TextEditingController(text: init);
        return AlertDialog(title: Text(t), content: TextField(controller: ctl, autofocus: true), actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(c, ctl.text.trim()), child: const Text('OK')),
        ]);
      });

  Future<void> add(String table, Rec v) async {
    try {
      await DB.db.insert(table, v);
    } catch (_) {
      if (mounted) snack(context, 'Name already exists');
    }
    load();
  }

  Future<void> del(String table, int id, String child, String col) async {
    if (await DB.count('SELECT COUNT(*) FROM $child WHERE $col=?', [id]) > 0) {
      if (mounted) snack(context, 'Not empty - cannot delete');
      return;
    }
    await DB.db.delete(table, where: 'id=?', whereArgs: [id]);
    load();
  }

  Future<void> assign(Rec k) async {
    final id = await showDialog<int>(
        context: context,
        builder: (c) => SimpleDialog(title: Text('Move ${k['name']} to PHCU'), children: [
              for (final p in ph) SimpleDialogOption(onPressed: () => Navigator.pop(c, p['id'] as int), child: Text('${p['name']}')),
            ]));
    if (id != null) {
      await DB.db.update('kebele', {'phcu_id': id}, where: 'id=?', whereArgs: [k['id']]);
      load();
    }
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('Kebele categories')),
        floatingActionButton: FloatingActionButton.extended(
            icon: const Icon(Icons.add),
            label: const Text('Add cluster'),
            onPressed: () async {
              final n = await ask('New cluster');
              if (n != null && n.isNotEmpty) add('cluster', {'name': n});
            }),
        body: ListView(children: [
          for (final cu in cl)
            ExpansionTile(title: Text('${cu['name']}'), leading: const Icon(Icons.hub), children: [
              for (final pu in ph.where((x) => x['cluster_id'] == cu['id']))
                ExpansionTile(title: Text('PHCU: ${pu['name']}'), children: [
                  for (final k in kb.where((x) => x['phcu_id'] == pu['id']))
                    ListTile(
                        title: Text('${k['name']}'),
                        subtitle: Text('Code ${k['code']}  (tap to move to another PHCU)'),
                        onTap: () => assign(k),
                        trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => del('kebele', k['id'] as int, 'household', 'kebele_id'))),
                  ListTile(
                      leading: const Icon(Icons.add),
                      title: const Text('Add kebele'),
                      onTap: () async {
                        final n = await ask('Kebele name');
                        if (n == null || n.isEmpty) return;
                        final next = kb.map((k) => int.tryParse('${k['code']}') ?? 0).fold(0, max) + 1;
                        final code = await ask('Kebele code (2 digits, used in CBHI code)', init: next.toString().padLeft(2, '0'));
                        if (code != null) add('kebele', {'phcu_id': pu['id'], 'name': n, 'code': code.padLeft(2, '0')});
                      }),
                  ListTile(leading: const Icon(Icons.delete), title: const Text('Delete this PHCU'), onTap: () => del('phcu', pu['id'] as int, 'kebele', 'phcu_id')),
                ]),
              ListTile(
                  leading: const Icon(Icons.add),
                  title: const Text('Add PHCU'),
                  onTap: () async {
                    final n = await ask('New PHCU');
                    if (n != null && n.isNotEmpty) add('phcu', {'cluster_id': cu['id'], 'name': n});
                  }),
              ListTile(leading: const Icon(Icons.delete), title: const Text('Delete this cluster'), onTap: () => del('cluster', cu['id'] as int, 'phcu', 'cluster_id')),
            ]),
        ]),
      );
}

// ---------------- 3. Settings ----------------
class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SP();
}

class _SP extends State<SettingsPage> {
  String? busy;
  Future<void> run(String label, Future<String?> Function() f) async {
    setState(() => busy = label);
    try {
      final r = await f();
      if (r != null && mounted) {
        await showDialog(context: context, builder: (c) => AlertDialog(content: SelectableText(r), actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('OK'))]));
      }
    } catch (e) {
      if (mounted) snack(context, 'Error: $e');
    }
    if (mounted) setState(() => busy = null);
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('Settings')),
        body: ListView(children: [
          if (busy != null) ...[const LinearProgressIndicator(), Padding(padding: const EdgeInsets.all(12), child: Text(busy!))],
          ListTile(
              leading: const Icon(Icons.upload_file),
              title: const Text('Import Excel / CSV'),
              subtitle: const Text('Registration form layout; existing codes are updated. Large files: prefer CSV.'),
              onTap: () async {
                final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['xlsx', 'csv']);
                final path = r?.files.single.path;
                if (path != null) run('Importing...', () => IO.importData(path, (s) => setState(() => busy = s)));
              }),
          ListTile(
              leading: const Icon(Icons.add_photo_alternate),
              title: const Text('Import member photos'),
              subtitle: const Text('File name = member ID with _ instead of /, e.g. P_05_04_09_02_0001_01.jpg'),
              onTap: () async {
                final r = await FilePicker.platform.pickFiles(type: FileType.image, allowMultiple: true);
                final paths = r?.files.map((f) => f.path).whereType<String>().toList();
                if (paths != null) run('Importing photos...', () async => '${await IO.importPhotos(paths)} of ${paths.length} photos matched a member.');
              }),
          ListTile(
              leading: const Icon(Icons.download),
              title: const Text('Export database to Excel'),
              subtitle: const Text('You choose the folder; the saved location is shown afterwards.'),
              onTap: () => run('Exporting...', () async {
                    final p = await IO.export();
                    return p == null ? null : 'Saved to:\n$p';
                  })),
          const Divider(),
          ListTile(leading: const Icon(Icons.storage), title: const Text('Local database (on this device)'), subtitle: SelectableText(DB.dbPath)),
          ListTile(leading: const Icon(Icons.photo_library), title: const Text('Photos folder'), subtitle: SelectableText(DB.photoDir)),
        ]),
      );
}

// ---------------- 4. Dashboard ----------------
class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});
  Future<Map<String, Object>> _load() async => {
        'hh': await DB.count('SELECT COUNT(*) FROM household'),
        'mem': await DB.count('SELECT COUNT(*) FROM member'),
        'photos': await DB.count('SELECT COUNT(*) FROM member WHERE photo IS NOT NULL'),
        'scale': await DB.q("SELECT CASE WHEN scale='' THEN 'Not set' ELSE scale END k, COUNT(*) n FROM household GROUP BY 1"),
        'status': await DB.q('SELECT status k, COUNT(*) n FROM household GROUP BY 1'),
        'area': await DB.q("SELECT CASE WHEN area='' THEN 'Not set' ELSE area END k, COUNT(*) n FROM household GROUP BY 1"),
        'gender': await DB.q("SELECT CASE WHEN gender='' THEN 'Not set' ELSE gender END k, COUNT(*) n FROM member GROUP BY 1"),
        'cluster': await DB.q('SELECT c.name k, COUNT(*) n FROM household h JOIN kebele b ON b.id=h.kebele_id JOIN phcu p ON p.id=b.phcu_id JOIN cluster c ON c.id=p.cluster_id GROUP BY 1 ORDER BY n DESC'),
        'kebele': await DB.q('SELECT b.name k, COUNT(*) n FROM household h JOIN kebele b ON b.id=h.kebele_id GROUP BY 1 ORDER BY n DESC LIMIT 20'),
      };

  Widget stat(String t, Object v) => Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(children: [Text('$v', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)), Text(t)])));

  Widget sec(String t, List<Rec> rows, {bool fee = false}) => Card(
      child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(t, style: const TextStyle(fontWeight: FontWeight.bold)),
            const Divider(),
            for (final r in rows)
              Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Row(children: [
                    Expanded(child: Text('${r['k']}')),
                    Text(fee && fees.containsKey(r['k']) ? '${r['n']}  •  ${(r['n'] as int) * fees[r['k']]!} birr' : '${r['n']}'),
                  ])),
          ])));

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('Dashboard')),
        body: FutureBuilder<Map<String, Object>>(
            future: _load(),
            builder: (_, s) {
              if (!s.hasData) return const Center(child: CircularProgressIndicator());
              final d = s.data!;
              return ListView(padding: const EdgeInsets.all(10), children: [
                Row(children: [Expanded(child: stat('Households', d['hh']!)), Expanded(child: stat('Members', d['mem']!)), Expanded(child: stat('With photo', d['photos']!))]),
                sec('Sliding scale (households • expected contribution)', d['scale'] as List<Rec>, fee: true),
                sec('Membership status', d['status'] as List<Rec>),
                sec('Rural / Town', d['area'] as List<Rec>),
                sec('Members by gender', d['gender'] as List<Rec>),
                sec('Households by cluster', d['cluster'] as List<Rec>),
                sec('Households by kebele (top 20)', d['kebele'] as List<Rec>),
              ]);
            }),
      );
}
