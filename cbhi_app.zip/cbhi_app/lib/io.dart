import 'dart:io';
import 'dart:typed_data';
import 'package:csv/csv.dart';
import 'package:excel/excel.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import 'db.dart';

String _s(dynamic v) {
  if (v == null) return '';
  if (v is double) return v == v.truncateToDouble() ? v.toInt().toString() : v.toString();
  return v.toString().trim();
}

String _norm(String v, List<String> items) {
  for (final i in items) {
    if (i.toLowerCase() == v.toLowerCase()) return i;
  }
  return '';
}

String _date(dynamic d, dynamic m, dynamic y) =>
    (_s(d).isEmpty && _s(m).isEmpty && _s(y).isEmpty) ? '' : '${_s(d)}/${_s(m)}/${_s(y)}';

class IO {
  /// Imports the CBHI registration form layout (.xlsx or .csv).
  /// Columns: A name, B-D DOB, E gender, F household code, G member code, H kebele, I gote,
  /// J relationship, K profession, L-N enrollment, O scale, P rural/town, Q has card, R FAN, S status (optional).
  static Future<String> importData(String path, void Function(String) prog) async {
    List<List<dynamic>> rows;
    if (path.toLowerCase().endsWith('.csv')) {
      rows = const CsvToListConverter(shouldParseNumbers: false).convert(await File(path).readAsString());
    } else {
      final x = Excel.decodeBytes(await File(path).readAsBytes());
      final sh = x.tables['CBHI Registration Form'] ?? x.tables.values.first;
      rows = sh.rows.map((r) => r.map((c) => c?.value).toList()).toList();
    }
    final hi = rows.indexWhere((r) => r.isNotEmpty && _s(r[0]).contains('Full Name'));
    final start = hi < 0 ? 0 : hi + 3;
    final kmap = {for (final k in await DB.db.query('kebele')) k['name'] as String: k['id'] as int};
    final hmap = {for (final h in await DB.db.query('household', columns: ['id', 'code'])) h['code'] as String: h['id'] as int};
    int hh = 0, mm = 0;
    int? unassigned;

    await DB.db.transaction((t) async {
      int? cur;
      String hcode = '';
      List<String> names = [];
      Future<void> flush() async {
        if (cur != null) {
          await t.update('household', {'search': '$hcode ${names.join(' ')}'.toLowerCase()}, where: 'id=?', whereArgs: [cur]);
        }
      }

      Future<int> newKebele(String name, String code) async {
        if (unassigned == null) {
          final e = await t.query('phcu', where: "name='Unassigned'");
          if (e.isNotEmpty) {
            unassigned = e.first['id'] as int;
          } else {
            await t.insert('cluster', {'name': 'Unassigned'}, conflictAlgorithm: ConflictAlgorithm.ignore);
            final cid = (await t.query('cluster', where: "name='Unassigned'")).first['id'] as int;
            unassigned = await t.insert('phcu', {'cluster_id': cid, 'name': 'Unassigned'});
          }
        }
        final parts = code.split('/');
        return t.insert('kebele', {'phcu_id': unassigned, 'name': name, 'code': parts.length >= 6 ? parts[4] : ''});
      }

      for (var i = start; i < rows.length; i++) {
        final r = List<dynamic>.from(rows[i]);
        while (r.length < 19) {
          r.add(null);
        }
        final name = _s(r[0]);
        if (name.isEmpty) continue;
        final code = _s(r[5]).toUpperCase().replaceAll(' ', '');
        if (code.isNotEmpty) {
          await flush();
          final kn = _s(r[7]).isEmpty ? 'Unassigned' : _s(r[7]);
          final kid = kmap[kn] ?? await newKebele(kn, code);
          kmap[kn] = kid;
          final data = <String, Object?>{
            'kebele_id': kid, 'gote': _s(r[8]), 'scale': _norm(_s(r[14]), fees.keys.toList()),
            'area': _norm(_s(r[15]), areas), 'has_card': _norm(_s(r[16]), yesNo),
            'fan': _s(r[17]), 'enroll': _date(r[11], r[12], r[13]),
          };
          final st = _s(r[18]).toLowerCase();
          if (st.startsWith('renew')) data['status'] = 'Renewed';
          if (st.startsWith('un')) data['status'] = 'Un-renewed';
          if (hmap.containsKey(code)) {
            cur = hmap[code];
            await t.update('household', data, where: 'id=?', whereArgs: [cur]);
            await t.delete('member', where: 'hh_id=?', whereArgs: [cur]);
          } else {
            cur = await t.insert('household', {...data, 'code': code});
            hmap[code] = cur!;
          }
          hcode = code;
          names = [_s(r[17])];
          hh++;
        }
        if (cur == null) continue;
        var rel = _s(r[9]);
        if (rel.toLowerCase().startsWith('household head')) rel = 'Household Head';
        var sub = _s(r[6]).padLeft(2, '0');
        if (rel == 'Household Head') sub = '00';
        await t.insert('member', {
          'hh_id': cur, 'sub_code': sub, 'name': name, 'dob': _date(r[1], r[2], r[3]),
          'gender': _norm(_s(r[4]), genders), 'relation': rel, 'profession': _s(r[10]),
        });
        names.add(name);
        mm++;
        if (mm % 500 == 0) prog('Imported $hh households, $mm members...');
      }
      await flush();
    });
    return 'Import done: $hh households, $mm members.';
  }

  /// Photo file name must be the member ID with / replaced by _  e.g. P_05_04_09_02_0001_01.jpg
  static Future<int> importPhotos(List<String> paths) async {
    var n = 0;
    for (final f in paths) {
      final stem = p.basenameWithoutExtension(f).toUpperCase();
      final i = stem.lastIndexOf('_');
      if (i < 0) continue;
      final r = await DB.q('SELECT m.id FROM member m JOIN household h ON h.id=m.hh_id WHERE h.code=? AND m.sub_code=?',
          [stem.substring(0, i).replaceAll('_', '/'), stem.substring(i + 1)]);
      if (r.isEmpty) continue;
      final dest = await DB.copyPhoto(f);
      await DB.db.update('member', {'photo': dest}, where: 'id=?', whereArgs: [r.first['id']]);
      n++;
    }
    return n;
  }

  /// Exports in the same layout as the registration form. Returns the saved path (null if cancelled).
  static Future<String?> export() async {
    final ex = Excel.createExcel();
    final sh = ex['CBHI Registration Form'];
    ex.delete('Sheet1');
    sh.appendRow(['CBHI Members & Beneficiaries Profile']);
    sh.appendRow(['', '', '', '', '', '', 'Region *', 'Somali', 'Zone *', 'Sitti', 'Woreda *', 'Shinile']);
    sh.appendRow(['']);
    sh.appendRow(['Full Name *', 'Date Of Birth *', '', '', 'Gender *', 'Household CBHI Id *', 'Beneficiary CBHI Id *', 'Kebele *', 'Gote', 'Relationship *', 'Profession', 'Enrollment Date *', '', '', 'Sliding Scale Category *', 'Rural / Town Admin *', 'Has CBHI Id Card (Yes/No) *', 'National Digital ID Card Number(FAN)*', 'Status of HH']);
    sh.appendRow(['', 'Day', 'Month', 'Year', '', '', '', '', '', '', '', 'Day', 'Month', 'Year']);
    sh.appendRow(['']);
    final data = await DB.q('''SELECT m.*, h.code hcode, h.gote, h.scale, h.status, h.area, h.has_card, h.fan, h.enroll, k.name kebele
        FROM member m JOIN household h ON h.id=m.hh_id LEFT JOIN kebele k ON k.id=h.kebele_id ORDER BY h.id, m.sub_code''');
    dynamic n(String? v) => int.tryParse(v ?? '') ?? (v ?? '');
    for (final m in data) {
      final d = '${m['dob']}'.split('/');
      final e = '${m['enroll']}'.split('/');
      final head = m['sub_code'] == '00';
      sh.appendRow([
        m['name'], n(d.isNotEmpty ? d[0] : ''), n(d.length > 1 ? d[1] : ''), n(d.length > 2 ? d[2] : ''),
        m['gender'], head ? m['hcode'] : '', m['sub_code'], m['kebele'], m['gote'], m['relation'], m['profession'],
        head ? n(e.isNotEmpty ? e[0] : '') : '', head ? n(e.length > 1 ? e[1] : '') : '', head ? n(e.length > 2 ? e[2] : '') : '',
        head ? m['scale'] : '', head ? m['area'] : '', head ? m['has_card'] : '', head ? m['fan'] : '', head ? m['status'] : '',
      ]);
    }
    final bytes = Uint8List.fromList(ex.encode()!);
    final name = 'CBHI_Export_${DateTime.now().toIso8601String().substring(0, 10)}.xlsx';
    final path = await FilePicker.platform.saveFile(dialogTitle: 'Save export', fileName: name, bytes: bytes);
    if (path == null) return null;
    if (!(Platform.isAndroid || Platform.isIOS)) await File(path).writeAsBytes(bytes);
    return path;
  }
}
