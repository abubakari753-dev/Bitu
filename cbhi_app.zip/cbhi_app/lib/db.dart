import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

typedef Rec = Map<String, Object?>;
const fees = {'Higher': 1930, 'Middle': 1310, 'Lower': 720};
const genders = ['Male', 'Female'];
const relations = ['Household Head', 'Parent', 'Husband', 'Wife', 'Son', 'Daughter', 'Other'];
const professions = ['Farmer', 'Pastoralist', 'Merchant', 'Job Seeker', 'Housewife', 'Stay at home Husband', 'Daily Laborer', 'Student', 'Disabled', 'Other'];
const statuses = ['Renewed', 'Un-renewed'];
const areas = ['Rural', 'Town'];
const yesNo = ['Yes', 'No'];

class DB {
  // Code format: P/<region>/<zone>/<woreda>/<kebele>/<0001>  (taken from the sample file)
  static const prefix = 'P', region = '05', zone = '04', woreda = '09';
  static late Database db;
  static late String photoDir, dbPath;

  static Future<void> init() async {
    if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
      sqfliteFfiInit();
      databaseFactory = databaseFactoryFfi;
    }
    final dir = await getApplicationSupportDirectory();
    photoDir = p.join(dir.path, 'photos');
    await Directory(photoDir).create(recursive: true);
    dbPath = p.join(dir.path, 'cbhi.db');
    db = await openDatabase(dbPath, version: 1, onCreate: (d, v) async {
      for (final s in [
        'CREATE TABLE cluster(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE)',
        'CREATE TABLE phcu(id INTEGER PRIMARY KEY AUTOINCREMENT, cluster_id INTEGER, name TEXT)',
        'CREATE TABLE kebele(id INTEGER PRIMARY KEY AUTOINCREMENT, phcu_id INTEGER, name TEXT UNIQUE, code TEXT)',
        "CREATE TABLE household(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, kebele_id INTEGER, gote TEXT DEFAULT '', scale TEXT DEFAULT '', status TEXT DEFAULT 'Un-renewed', area TEXT DEFAULT '', has_card TEXT DEFAULT '', fan TEXT DEFAULT '', enroll TEXT DEFAULT '', search TEXT DEFAULT '')",
        "CREATE TABLE member(id INTEGER PRIMARY KEY AUTOINCREMENT, hh_id INTEGER, sub_code TEXT, name TEXT, dob TEXT DEFAULT '', gender TEXT DEFAULT '', relation TEXT DEFAULT '', profession TEXT DEFAULT '', photo TEXT)",
        'CREATE INDEX ix_m_hh ON member(hh_id)',
        'CREATE INDEX ix_h_k ON household(kebele_id)',
      ]) {
        await d.execute(s);
      }
    });
  }

  static Future<List<Rec>> q(String sql, [List<Object?>? a]) => db.rawQuery(sql, a);
  static Future<int> count(String sql, [List<Object?>? a]) async =>
      Sqflite.firstIntValue(await db.rawQuery(sql, a)) ?? 0;

  static Future<String> copyPhoto(String src) async {
    final dest = p.join(photoDir, '${DateTime.now().microsecondsSinceEpoch}${p.extension(src)}');
    await File(src).copy(dest);
    return dest;
  }

  /// Auto-generates the next unique household code for a kebele.
  static Future<String> nextCode(int kebeleId) async {
    final k = (await q('SELECT code FROM kebele WHERE id=?', [kebeleId])).first;
    final kc = '${k['code'] ?? ''}'.padLeft(2, '0');
    final pre = '$prefix/$region/$zone/$woreda/$kc/';
    final r = await q('SELECT MAX(CAST(substr(code, ?) AS INTEGER)) m FROM household WHERE code LIKE ?',
        [pre.length + 1, '$pre%']);
    final m = (r.first['m'] as int?) ?? 0;
    return pre + (m + 1).toString().padLeft(4, '0');
  }

  static Future<void> saveHousehold(int? id, Rec h, List<Rec> ms) async {
    final code = id == null ? await nextCode(h['kebele_id'] as int) : null;
    final names = ms.map((m) => '${m['name']}').join(' ');
    await db.transaction((t) async {
      int hid;
      if (id == null) {
        hid = await t.insert('household', {...h, 'code': code});
      } else {
        hid = id;
        await t.update('household', h, where: 'id=?', whereArgs: [hid]);
      }
      await t.delete('member', where: 'hh_id=?', whereArgs: [hid]);
      for (final m in ms) {
        await t.insert('member', {
          'hh_id': hid, 'sub_code': m['sub_code'], 'name': m['name'], 'dob': m['dob'] ?? '',
          'gender': m['gender'] ?? '', 'relation': m['relation'] ?? '',
          'profession': m['profession'] ?? '', 'photo': m['photo'],
        });
      }
      final c = code ?? (await t.query('household', columns: ['code'], where: 'id=?', whereArgs: [hid])).first['code'];
      await t.update('household', {'search': '$c ${h['fan']} $names'.toLowerCase()}, where: 'id=?', whereArgs: [hid]);
    });
  }

  static Future<void> deleteHousehold(int id) async {
    await db.delete('member', where: 'hh_id=?', whereArgs: [id]);
    await db.delete('household', where: 'id=?', whereArgs: [id]);
  }
}
