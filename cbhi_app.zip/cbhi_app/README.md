# CBHI Registration (offline) - Android + Windows

## Get the installable files (no setup on your PC)
1. Create a free GitHub repository and upload this whole folder (keep the .github folder).
2. Open the Actions tab -> "Build CBHI app" -> Run workflow.
3. When it finishes, download `cbhi-apk` (app-release.apk -> copy to phone and install)
   and `cbhi-windows` (folder; run cbhi_app.exe).

## Or build locally
Install Flutter, then in this folder:
    flutter create --platforms=android,windows --project-name cbhi_app .
    flutter pub get
    flutter build apk --release        # build/app/outputs/flutter-apk/app-release.apk
    flutter build windows --release    # build/windows/x64/runner/Release
If Windows says sqlite3.dll is missing, copy sqlite3.dll next to cbhi_app.exe.

## Notes
- Code format is set in lib/db.dart (P/05/04/09/<kebele>/<0001>, member 00 = head, 01, 02...).
- Import reads the registration-form layout; an optional column S = Renewed / Un-renewed.
- Data is stored in a local SQLite file; photos are stored as files (path shown in Settings).
